# Proguard rules for PotrikaGhor
