class Cat {
  const Cat(this.id, this.label);
  final String id;
  final String label;
}

class Paper {
  const Paper(this.bn, this.en, this.url, this.cat, {this.custom = false});

  final String bn;
  final String en;
  final String url;
  final String cat;

  /// true for newspapers the user added by hand.
  final bool custom;

  String get host {
    final h = Uri.tryParse(url)?.host ?? '';
    return h.startsWith('www.') ? h.substring(4) : h;
  }

  /// The website's own logo (favicon), fetched by domain.
  String get logoUrl => 'https://www.google.com/s2/favicons?sz=128&domain=$host';

  Map<String, String> toJson() => {'bn': bn, 'en': en, 'url': url, 'cat': cat};

  factory Paper.fromJson(Map<String, dynamic> j) => Paper(
        j['bn'] as String,
        (j['en'] as String?) ?? '',
        j['url'] as String,
        (j['cat'] as String?) ?? 'mine',
        custom: true,
      );
}

class Bookmark {
  const Bookmark({
    required this.url,
    required this.title,
    required this.paperUrl,
    required this.savedAt,
  });

  final String url;
  final String title;
  final String paperUrl;
  final int savedAt;

  Map<String, dynamic> toJson() => {
        'url': url,
        'title': title,
        'paperUrl': paperUrl,
        'savedAt': savedAt,
      };

  factory Bookmark.fromJson(Map<String, dynamic> j) => Bookmark(
        url: j['url'] as String,
        title: j['title'] as String,
        paperUrl: j['paperUrl'] as String,
        savedAt: j['savedAt'] as int,
      );
}
