import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const brandGreen = Color(0xFF0E6B4A);
const flagRed = Color(0xFFD4382C);

/// Accent colours the user can pick in Settings.
const accentColors = <Color>[
  brandGreen,
  Color(0xFF1565C0),
  Color(0xFF6A3FB5),
  Color(0xFFD9622B),
  Color(0xFFC2185B),
  Color(0xFF00838F),
];
const accentNames = ['সবুজ', 'নীল', 'বেগুনি', 'কমলা', 'গোলাপি', 'সায়ান'];

TextStyle serif({double? size, FontWeight weight = FontWeight.w600, Color? color, double? height}) =>
    GoogleFonts.notoSerifBengali(fontSize: size, fontWeight: weight, color: color, height: height);

ThemeData buildTheme(Brightness brightness, {Color seed = brandGreen, String style = 'normal'}) {
  final dark = brightness == Brightness.dark;
  var scheme = ColorScheme.fromSeed(seedColor: seed, brightness: brightness);
  var bg = dark ? const Color(0xFF0E1512) : const Color(0xFFF2F4F0);

  if (dark && style == 'amoled') {
    // Pure black: saves battery on AMOLED screens.
    bg = Colors.black;
    scheme = scheme.copyWith(
      surface: Colors.black,
      surfaceContainerLowest: const Color(0xFF0B0B0B),
      surfaceContainerLow: const Color(0xFF111111),
      surfaceContainer: const Color(0xFF151515),
      surfaceContainerHigh: const Color(0xFF1A1A1A),
      surfaceContainerHighest: const Color(0xFF202020),
      outlineVariant: const Color(0xFF2B2B2B),
    );
  } else if (!dark && style == 'sepia') {
    // Warm paper tone: easy on the eyes for long reading.
    bg = const Color(0xFFF3EAD3);
    scheme = scheme.copyWith(
      surface: const Color(0xFFF3EAD3),
      onSurface: const Color(0xFF3B2F1E),
      onSurfaceVariant: const Color(0xFF6B5B43),
      surfaceContainerLowest: const Color(0xFFFAF3E1),
      surfaceContainerLow: const Color(0xFFF7EFDB),
      surfaceContainer: const Color(0xFFF1E7CE),
      surfaceContainerHigh: const Color(0xFFEBE0C4),
      surfaceContainerHighest: const Color(0xFFE5D9BB),
      outlineVariant: const Color(0xFFD8C9A3),
    );
  }

  final base = ThemeData(useMaterial3: true, colorScheme: scheme, brightness: brightness);

  return base.copyWith(
    textTheme: GoogleFonts.hindSiliguriTextTheme(base.textTheme),
    scaffoldBackgroundColor: bg,
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
      titleTextStyle: serif(size: 22, color: scheme.onSurface),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: scheme.surfaceContainerLowest,
      indicatorColor: scheme.primaryContainer,
      labelTextStyle: WidgetStatePropertyAll(
        GoogleFonts.hindSiliguri(fontSize: 13, fontWeight: FontWeight.w500),
      ),
    ),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: ZoomPageTransitionsBuilder(),
    }),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
