import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/papers.dart';
import '../models.dart';

/// Everything the user can change or save. Persisted with SharedPreferences.
class AppState extends ChangeNotifier {
  AppState._(this._p) {
    _load();
  }

  static Future<AppState> load() async => AppState._(await SharedPreferences.getInstance());

  final SharedPreferences _p;

  List<Paper> customPapers = [];
  Map<String, String> urlFixes = {};
  List<String> favs = [];
  List<String> recents = [];
  List<Bookmark> bookmarks = [];
  ThemeMode themeMode = ThemeMode.system;
  double textScale = 1.0;
  String themeStyle = 'normal'; // normal | amoled | sepia
  int accent = 0;
  bool hideAds = true;
  bool gridView = false;
  bool readerNight = false;
  bool readerDesktop = false;
  int readerZoom = 100;

  /// Papers the user added come first, then the built-in list.
  List<Paper> get allPapers => [...customPapers, ...papers.map(_withFix)];

  Paper _withFix(Paper p) => urlFixes.containsKey(p.url) ? p.withFix(urlFixes[p.url]) : p;

  Paper? paperFor(String url) {
    for (final p in customPapers) {
      if (p.url == url) return p;
    }
    final b = builtInPaperFor(url);
    return b == null ? null : _withFix(b);
  }

  /// Save (or clear, with null) a corrected link for a built-in paper.
  void setUrlFix(String originalUrl, String? newUrl) {
    if (newUrl == null || newUrl == originalUrl) {
      urlFixes.remove(originalUrl);
    } else {
      urlFixes[originalUrl] = newUrl;
    }
    _p.setString('urlFixes', jsonEncode(urlFixes));
    notifyListeners();
  }

  void _load() {
    try {
      urlFixes = Map<String, String>.from(
          jsonDecode(_p.getString('urlFixes') ?? '{}') as Map);
    } catch (_) {
      urlFixes = {};
    }
    customPapers = (_p.getStringList('custom') ?? [])
        .map((s) => Paper.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
    favs = (_p.getStringList('favs') ?? []).where((u) => paperFor(u) != null).toList();
    recents = (_p.getStringList('recents') ?? []).where((u) => paperFor(u) != null).toList();
    bookmarks = (_p.getStringList('bookmarks') ?? [])
        .map((s) => Bookmark.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
    themeMode = ThemeMode.values[(_p.getInt('theme') ?? 0).clamp(0, 2)];
    textScale = _p.getDouble('textScale') ?? 1.0;
    themeStyle = _p.getString('themeStyle') ?? 'normal';
    accent = (_p.getInt('accent') ?? 0).clamp(0, 5);
    hideAds = _p.getBool('hideAds') ?? true;
    gridView = _p.getBool('grid') ?? false;
    readerNight = _p.getBool('readerNight') ?? false;
    readerDesktop = _p.getBool('readerDesktop') ?? false;
    readerZoom = _p.getInt('readerZoom') ?? 100;
  }

  // ---- papers added by the user ----
  void addCustom(Paper p) {
    customPapers.insert(0, p);
    _saveCustom();
  }

  void updateCustom(String oldUrl, Paper p) {
    final i = customPapers.indexWhere((x) => x.url == oldUrl);
    if (i < 0) return;
    customPapers[i] = p;
    if (oldUrl != p.url) {
      favs = favs.map((u) => u == oldUrl ? p.url : u).toList();
      recents = recents.map((u) => u == oldUrl ? p.url : u).toList();
      bookmarks = bookmarks
          .map((b) => b.paperUrl == oldUrl
              ? Bookmark(url: b.url, title: b.title, paperUrl: p.url, savedAt: b.savedAt)
              : b)
          .toList();
      _p.setStringList('favs', favs);
      _p.setStringList('recents', recents);
      _p.setStringList('bookmarks', bookmarks.map((b) => jsonEncode(b.toJson())).toList());
    }
    _saveCustom();
  }

  void removeCustom(String url) {
    customPapers.removeWhere((p) => p.url == url);
    favs.remove(url);
    recents.remove(url);
    _p.setStringList('favs', favs);
    _p.setStringList('recents', recents);
    _saveCustom();
  }

  void restoreCustom(Paper p, int index) {
    if (paperFor(p.url) != null) return;
    customPapers.insert(index.clamp(0, customPapers.length), p);
    _saveCustom();
  }

  void _saveCustom() {
    _p.setStringList('custom', customPapers.map((p) => jsonEncode(p.toJson())).toList());
    notifyListeners();
  }

  // ---- favourites ----
  bool isFav(String url) => favs.contains(url);

  void toggleFav(String url) {
    if (isFav(url)) {
      favs.remove(url);
    } else {
      favs.insert(0, url);
    }
    _saveFavs();
  }

  void removeFav(String url) {
    favs.remove(url);
    _saveFavs();
  }

  void restoreFav(String url, int index) {
    if (favs.contains(url)) return;
    favs.insert(index.clamp(0, favs.length), url);
    _saveFavs();
  }

  void reorderFavs(int oldIndex, int newIndex) {
    final u = favs.removeAt(oldIndex);
    favs.insert(newIndex, u);
    _saveFavs();
  }

  void _saveFavs() {
    _p.setStringList('favs', favs);
    notifyListeners();
  }

  // ---- recents ----
  void addRecent(String url) {
    recents.remove(url);
    recents.insert(0, url);
    recents = recents.take(12).toList();
    _p.setStringList('recents', recents);
    notifyListeners();
  }

  // ---- bookmarks ----
  bool isBookmarked(String url) => bookmarks.any((b) => b.url == url);

  void addBookmark(Bookmark b) {
    bookmarks.removeWhere((x) => x.url == b.url);
    bookmarks.insert(0, b);
    _saveBookmarks();
  }

  void removeBookmark(String url) {
    bookmarks.removeWhere((b) => b.url == url);
    _saveBookmarks();
  }

  void restoreBookmark(Bookmark b, int index) {
    if (isBookmarked(b.url)) return;
    bookmarks.insert(index.clamp(0, bookmarks.length), b);
    _saveBookmarks();
  }

  void _saveBookmarks() {
    _p.setStringList('bookmarks', bookmarks.map((b) => jsonEncode(b.toJson())).toList());
    notifyListeners();
  }

  // ---- settings ----
  void setThemeMode(ThemeMode m) {
    themeMode = m;
    _p.setInt('theme', m.index);
    notifyListeners();
  }

  void setThemeStyle(String s) {
    themeStyle = s;
    _p.setString('themeStyle', s);
    // AMOLED needs dark mode, sepia needs light mode.
    themeMode = s == 'amoled'
        ? ThemeMode.dark
        : s == 'sepia'
            ? ThemeMode.light
            : ThemeMode.system;
    _p.setInt('theme', themeMode.index);
    notifyListeners();
  }

  void setAccent(int i) {
    accent = i.clamp(0, 5);
    _p.setInt('accent', accent);
    notifyListeners();
  }

  void setHideAds(bool v) {
    hideAds = v;
    _p.setBool('hideAds', v);
    notifyListeners();
  }

  // ---- backup / restore ----
  String exportBackup() => jsonEncode({
        'app': 'potrikaghor',
        'v': 1,
        'favs': favs,
        'recents': recents,
        'bookmarks': bookmarks.map((b) => b.toJson()).toList(),
        'custom': customPapers.map((p) => p.toJson()).toList(),
        'fixes': urlFixes,
        'settings': {
          'theme': themeMode.index,
          'textScale': textScale,
          'grid': gridView,
          'readerNight': readerNight,
          'readerDesktop': readerDesktop,
          'readerZoom': readerZoom,
          'themeStyle': themeStyle,
          'accent': accent,
          'hideAds': hideAds,
        },
      });

  /// Returns null on success, or an error message in Bangla.
  String? importBackup(String text) {
    try {
      final m = jsonDecode(text.trim()) as Map<String, dynamic>;
      if (m['app'] != 'potrikaghor') return 'এটি পত্রিকাঘরের ব্যাকআপ কোড নয়';

      urlFixes = Map<String, String>.from((m['fixes'] as Map?) ?? {});
      _p.setString('urlFixes', jsonEncode(urlFixes));
      customPapers = ((m['custom'] as List?) ?? [])
          .map((e) => Paper.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      bookmarks = ((m['bookmarks'] as List?) ?? [])
          .map((e) => Bookmark.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      favs = ((m['favs'] as List?) ?? []).map((e) => e.toString()).where((u) => paperFor(u) != null).toList();
      recents =
          ((m['recents'] as List?) ?? []).map((e) => e.toString()).where((u) => paperFor(u) != null).toList();

      final s = Map<String, dynamic>.from((m['settings'] as Map?) ?? {});
      themeMode = ThemeMode.values[((s['theme'] as num?)?.toInt() ?? 0).clamp(0, 2)];
      textScale = ((s['textScale'] as num?)?.toDouble() ?? 1.0).clamp(0.85, 1.4);
      gridView = (s['grid'] as bool?) ?? false;
      readerNight = (s['readerNight'] as bool?) ?? false;
      readerDesktop = (s['readerDesktop'] as bool?) ?? false;
      readerZoom = ((s['readerZoom'] as num?)?.toInt() ?? 100).clamp(70, 200);
      themeStyle = (s['themeStyle'] as String?) ?? 'normal';
      accent = ((s['accent'] as num?)?.toInt() ?? 0).clamp(0, 5);
      hideAds = (s['hideAds'] as bool?) ?? true;

      _p.setStringList('custom', customPapers.map((p) => jsonEncode(p.toJson())).toList());
      _p.setStringList('bookmarks', bookmarks.map((b) => jsonEncode(b.toJson())).toList());
      _p.setStringList('favs', favs);
      _p.setStringList('recents', recents);
      _p.setInt('theme', themeMode.index);
      _p.setDouble('textScale', textScale);
      _p.setBool('grid', gridView);
      _p.setBool('readerNight', readerNight);
      _p.setBool('readerDesktop', readerDesktop);
      _p.setInt('readerZoom', readerZoom);
      _p.setString('themeStyle', themeStyle);
      _p.setInt('accent', accent);
      _p.setBool('hideAds', hideAds);
      notifyListeners();
      return null;
    } catch (_) {
      return 'ব্যাকআপ কোডটি পড়া যায়নি। পুরোটা কপি করেছেন কিনা দেখুন';
    }
  }

  void setTextScale(double v) {
    textScale = v;
    _p.setDouble('textScale', v);
    notifyListeners();
  }

  void setGridView(bool v) {
    gridView = v;
    _p.setBool('grid', v);
    notifyListeners();
  }

  void setReaderNight(bool v) {
    readerNight = v;
    _p.setBool('readerNight', v);
    notifyListeners();
  }

  void setReaderDesktop(bool v) {
    readerDesktop = v;
    _p.setBool('readerDesktop', v);
    notifyListeners();
  }

  void setReaderZoom(int v) {
    readerZoom = v;
    _p.setInt('readerZoom', v);
    notifyListeners();
  }

  Future<void> clearUserData() async {
    favs = [];
    recents = [];
    bookmarks = [];
    await _p.remove('favs');
    await _p.remove('recents');
    await _p.remove('bookmarks');
    notifyListeners();
  }
}
