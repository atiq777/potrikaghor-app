import 'dart:convert';
import 'dart:io';

/// One headline from Google News (RSS).
class NewsItem {
  const NewsItem({
    required this.title,
    required this.source,
    required this.sourceUrl,
    required this.link,
    this.time,
  });

  final String title;
  final String source;
  final String sourceUrl;
  final String link;
  final DateTime? time;
}

/// Fetches headlines. Empty [query] = today's top headlines (Bangladesh, Bangla).
Future<List<NewsItem>> fetchNews({String query = ''}) async {
  final q = query.trim();
  final uri = q.isEmpty
      ? Uri.https('news.google.com', '/rss', {'hl': 'bn', 'gl': 'BD', 'ceid': 'BD:bn'})
      : Uri.https('news.google.com', '/rss/search', {
          'q': q,
          'hl': 'bn',
          'gl': 'BD',
          'ceid': 'BD:bn',
        });

  final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
  try {
    final req = await client.getUrl(uri);
    req.headers.set(HttpHeaders.userAgentHeader, 'Mozilla/5.0 (Linux; Android 14) PotrikaGhor');
    final res = await req.close().timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw HttpException('status ${res.statusCode}');
    final body = await res.transform(utf8.decoder).join();
    return _parse(body);
  } finally {
    client.close();
  }
}

List<NewsItem> _parse(String xml) {
  final out = <NewsItem>[];
  for (final m in RegExp(r'<item>(.*?)</item>', dotAll: true).allMatches(xml)) {
    final b = m.group(1)!;
    var title = _text(b, 'title');
    final link = _text(b, 'link');
    final pub = _text(b, 'pubDate');
    final s = RegExp(r'<source[^>]*url="([^"]*)"[^>]*>(.*?)</source>', dotAll: true).firstMatch(b);
    final sourceUrl = s?.group(1) ?? '';
    final source = s == null ? '' : _unescape(s.group(2)!);
    final suffix = ' - $source';
    if (source.isNotEmpty && title.endsWith(suffix)) {
      title = title.substring(0, title.length - suffix.length);
    }
    if (title.isEmpty || link.isEmpty) continue;
    out.add(NewsItem(
      title: title,
      source: source.isEmpty ? 'অজানা উৎস' : source,
      sourceUrl: sourceUrl,
      link: link,
      time: _date(pub),
    ));
  }
  return out;
}

String _text(String block, String tag) {
  final m = RegExp('<$tag[^>]*>(.*?)</$tag>', dotAll: true).firstMatch(block);
  return m == null ? '' : _unescape(m.group(1)!);
}

String _unescape(String s) {
  var t = s.replaceAllMapped(
    RegExp(r'<!\[CDATA\[(.*?)\]\]>', dotAll: true),
    (m) => m.group(1)!,
  );
  t = t.replaceAllMapped(RegExp(r'&#(x?)([0-9a-fA-F]+);'), (m) {
    final code = int.tryParse(m.group(2)!, radix: m.group(1) == 'x' ? 16 : 10);
    return code == null ? m.group(0)! : String.fromCharCode(code);
  });
  t = t
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');
  return t.trim();
}

DateTime? _date(String s) {
  if (s.isEmpty) return null;
  try {
    return HttpDate.parse(s);
  } catch (_) {
    return null;
  }
}
