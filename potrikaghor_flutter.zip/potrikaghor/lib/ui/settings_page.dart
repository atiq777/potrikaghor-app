import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'link_check_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          const _Section('চেহারা'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: SegmentedButton<ThemeMode>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('অটো'), icon: Icon(Icons.brightness_auto_outlined)),
                ButtonSegment(value: ThemeMode.light, label: Text('দিন'), icon: Icon(Icons.light_mode_outlined)),
                ButtonSegment(value: ThemeMode.dark, label: Text('রাত'), icon: Icon(Icons.dark_mode_outlined)),
              ],
              selected: {app.themeMode},
              onSelectionChanged: (s) => app.setThemeMode(s.first),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: SegmentedButton<String>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 'normal', label: Text('সাধারণ')),
                ButtonSegment(value: 'amoled', label: Text('AMOLED কালো')),
                ButtonSegment(value: 'sepia', label: Text('সেপিয়া')),
              ],
              selected: {app.themeStyle},
              onSelectionChanged: (s) => app.setThemeStyle(s.first),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
            child: Text('অ্যাকসেন্ট রঙ', style: Theme.of(context).textTheme.bodyMedium),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
            child: Wrap(
              spacing: 12,
              runSpacing: 10,
              children: [
                for (var i = 0; i < accentColors.length; i++)
                  Semantics(
                    label: accentNames[i],
                    button: true,
                    child: GestureDetector(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        app.setAccent(i);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: accentColors[i],
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: app.accent == i ? cs.onSurface : Colors.transparent,
                            width: 3,
                          ),
                        ),
                        child: app.accent == i
                            ? const Icon(Icons.check_rounded, color: Colors.white, size: 22)
                            : null,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          ListTile(
            title: const Text('অ্যাপের লেখার আকার'),
            subtitle: Slider(
              value: app.textScale,
              min: 0.85,
              max: 1.4,
              divisions: 11,
              label: '${bnDigits((app.textScale * 100).round())}%',
              onChanged: app.setTextScale,
            ),
            trailing: Text(
              'অ',
              style: serif(size: 18 * app.textScale, color: cs.primary, weight: FontWeight.w700),
            ),
          ),
          const _Section('পড়ার পর্দা'),
          SwitchListTile(
            title: const Text('রাতের মোড'),
            subtitle: const Text('ওয়েবসাইটের রং উল্টে চোখের আরাম বাড়ায়'),
            value: app.readerNight,
            onChanged: app.setReaderNight,
          ),
          SwitchListTile(
            title: const Text('ডেস্কটপ সাইট'),
            subtitle: const Text('মোবাইলের বদলে পূর্ণ সংস্করণ খুলবে'),
            value: app.readerDesktop,
            onChanged: app.setReaderDesktop,
          ),
          SwitchListTile(
            title: const Text('বিজ্ঞাপন কমান (পরীক্ষামূলক)'),
            subtitle: const Text('পত্রিকার পাতার ভাসমান ও ব্যানার বিজ্ঞাপন লুকানোর চেষ্টা করে'),
            value: app.hideAds,
            onChanged: app.setHideAds,
          ),
          ListTile(
            title: const Text('ওয়েবসাইটের লেখার আকার'),
            subtitle: Slider(
              value: app.readerZoom.toDouble(),
              min: 70,
              max: 200,
              divisions: 13,
              label: '${bnDigits(app.readerZoom)}%',
              onChanged: (v) => app.setReaderZoom(v.round()),
            ),
            trailing: Text(bnDigits('${app.readerZoom}%')),
          ),
          const _Section('ব্যাকআপ'),
          ListTile(
            leading: const Icon(Icons.copy_all_rounded),
            title: const Text('ব্যাকআপ কপি করুন'),
            subtitle: const Text('প্রিয়, বুকমার্ক, নিজের যোগ করা পত্রিকা ও সেটিংস একটি কোডে'),
            onTap: () {
              Clipboard.setData(ClipboardData(text: app.exportBackup()));
              toast(context, 'ব্যাকআপ কোড কপি হয়েছে। কোথাও সেভ করে রাখুন');
            },
          ),
          ListTile(
            leading: const Icon(Icons.ios_share_rounded),
            title: const Text('ব্যাকআপ শেয়ার করুন'),
            subtitle: const Text('হোয়াটসঅ্যাপ বা নোটে নিজেকে পাঠিয়ে রাখুন'),
            onTap: () => Share.share(app.exportBackup()),
          ),
          ListTile(
            leading: const Icon(Icons.settings_backup_restore_rounded),
            title: const Text('ব্যাকআপ থেকে ফেরান'),
            subtitle: const Text('আগের কপি করা কোড পেস্ট করুন'),
            onTap: () => _restore(context, app),
          ),
          const _Section('তথ্য ও স্টোরেজ'),
          ListTile(
            leading: const Icon(Icons.fact_check_outlined),
            title: const Text('লিংক পরীক্ষা'),
            subtitle: const Text('কোন পত্রিকা খুলছে না, নিজে থেকে খুঁজে দেখাবে'),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const LinkCheckPage()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.cleaning_services_outlined),
            title: const Text('ক্যাশ মুছুন'),
            subtitle: const Text('ওয়েবসাইটের সাময়িক ফাইল সরিয়ে জায়গা খালি করে'),
            onTap: () async {
              final c = WebViewController();
              await c.clearCache();
              await c.clearLocalStorage();
              if (context.mounted) toast(context, 'ক্যাশ মোছা হয়েছে');
            },
          ),
          ListTile(
            leading: Icon(Icons.delete_outline, color: cs.error),
            title: Text('প্রিয়, বুকমার্ক ও ইতিহাস মুছুন', style: TextStyle(color: cs.error)),
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('সব মুছে ফেলবেন?'),
                  content: const Text('প্রিয় পত্রিকা, বুকমার্ক এবং সম্প্রতি খোলা তালিকা মুছে যাবে।'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
                    FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('মুছুন')),
                  ],
                ),
              );
              if (ok == true) {
                await app.clearUserData();
                if (context.mounted) toast(context, 'মুছে ফেলা হয়েছে');
              }
            },
          ),
          const _Section('সম্পর্কে'),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('পত্রিকাঘর'),
            subtitle: Text('সংস্করণ ১.৩.১ · সব পত্রিকা এক জায়গায়'),
          ),
        ],
      ),
    );
  }
}

Future<void> _restore(BuildContext context, AppState app) async {
  final ctl = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('ব্যাকআপ থেকে ফেরান'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('আগে কপি করা ব্যাকআপ কোড এখানে পেস্ট করুন। বর্তমান প্রিয়, বুকমার্ক ও সেটিংস বদলে যাবে।'),
          const SizedBox(height: 12),
          TextField(
            controller: ctl,
            maxLines: 5,
            minLines: 3,
            decoration: const InputDecoration(
              hintText: 'ব্যাকআপ কোড',
              border: OutlineInputBorder(),
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              icon: const Icon(Icons.content_paste_rounded, size: 18),
              label: const Text('পেস্ট'),
              onPressed: () async {
                final d = await Clipboard.getData('text/plain');
                ctl.text = d?.text ?? '';
              },
            ),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ফেরান')),
      ],
    ),
  );
  final text = ctl.text;
  ctl.dispose();
  if (ok != true || !context.mounted) return;
  final err = app.importBackup(text);
  toast(context, err ?? 'ব্যাকআপ ফিরিয়ে আনা হয়েছে');
}

class _Section extends StatelessWidget {
  const _Section(this.label);

  final String label;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
        child: Text(
          label,
          style: serif(size: 15, color: Theme.of(context).colorScheme.primary, weight: FontWeight.w700),
        ),
      );
}
