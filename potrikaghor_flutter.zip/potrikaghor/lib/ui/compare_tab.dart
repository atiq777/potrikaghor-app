import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../news.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'widgets.dart';

/// Search a topic and see how different newspapers headline it.
class CompareTab extends StatefulWidget {
  const CompareTab({super.key});

  @override
  State<CompareTab> createState() => _CompareTabState();
}

class _CompareTabState extends State<CompareTab> with AutomaticKeepAliveClientMixin {
  static const _topics = [
    'আজকের শীর্ষ',
    'ক্রিকেট',
    'রাজনীতি',
    'অর্থনীতি',
    'আবহাওয়া',
    'বিনোদন',
    'প্রযুক্তি',
    'শিক্ষা',
  ];

  final TextEditingController _ctl = TextEditingController();
  List<NewsItem> _items = [];
  bool _loading = false;
  String? _error;
  String _topic = '';
  bool _bySource = false;
  int _req = 0;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load('');
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  Future<void> _load(String topic) async {
    final id = ++_req;
    setState(() {
      _topic = topic;
      _loading = true;
      _error = null;
    });
    try {
      final r = await fetchNews(query: topic);
      if (!mounted || id != _req) return;
      setState(() {
        _items = r;
        _loading = false;
      });
    } catch (_) {
      if (!mounted || id != _req) return;
      setState(() {
        _error = 'খবর আনা যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।';
        _loading = false;
      });
    }
  }

  Paper _paperFor(AppState app, NewsItem n) {
    var h = Uri.tryParse(n.sourceUrl)?.host ?? '';
    if (h.startsWith('www.')) h = h.substring(4);
    if (h.isNotEmpty) {
      for (final p in app.allPapers) {
        if (p.host == h) return p;
      }
    }
    return Paper(n.source, '', n.sourceUrl, 'online');
  }

  void _open(AppState app, NewsItem n) {
    openReader(context, _paperFor(app, n), url: n.link);
  }

  Widget _tile(AppState app, NewsItem n) {
    final cs = Theme.of(context).colorScheme;
    final p = _paperFor(app, n);
    final t = n.time;
    return InkWell(
      onTap: () => _open(app, n),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PaperAvatar(p, size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    n.title,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: serif(size: 15.5, weight: FontWeight.w500, height: 1.45),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    t == null ? n.source : '${n.source} · ${bnAgo(t.millisecondsSinceEpoch)}',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: cs.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _grouped(AppState app) {
    final cs = Theme.of(context).colorScheme;
    final groups = <String, List<NewsItem>>{};
    for (final n in _items) {
      groups.putIfAbsent(n.source, () => []).add(n);
    }
    final keys = groups.keys.toList()
      ..sort((a, b) => groups[b]!.length.compareTo(groups[a]!.length));
    final out = <Widget>[];
    for (final k in keys) {
      final list = groups[k]!;
      final p = _paperFor(app, list.first);
      out.add(Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
        child: Row(
          children: [
            PaperAvatar(p, size: 34),
            const SizedBox(width: 10),
            Expanded(
              child: Text(k, style: serif(size: 16, weight: FontWeight.w700)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2),
              decoration: BoxDecoration(
                color: cs.primaryContainer,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '${bnDigits(list.length)}টি',
                style: TextStyle(fontSize: 12, color: cs.onPrimaryContainer),
              ),
            ),
          ],
        ),
      ));
      for (final n in list) {
        out.add(InkWell(
          onTap: () => _open(app, n),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(60, 6, 16, 6),
            child: Text(
              n.title,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: serif(size: 14.5, weight: FontWeight.w400, height: 1.45),
            ),
          ),
        ));
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    final sourceCount = _items.map((e) => e.source).toSet().length;

    Widget body;
    if (_loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      body = EmptyState(
        icon: Icons.cloud_off_rounded,
        title: 'সংযোগ পাওয়া যায়নি',
        body: _error!,
        actionLabel: 'আবার চেষ্টা করুন',
        onAction: () => _load(_topic),
      );
    } else if (_items.isEmpty) {
      body = const EmptyState(
        icon: Icons.search_off_rounded,
        title: 'কোনো খবর পাওয়া যায়নি',
        body: 'অন্য শব্দ দিয়ে খুঁজে দেখুন।',
      );
    } else {
      body = RefreshIndicator(
        onRefresh: () => _load(_topic),
        child: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
              child: Text(
                '${bnDigits(_items.length)}টি খবর · ${bnDigits(sourceCount)}টি পত্রিকা · উৎস: Google News',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ),
            if (_bySource)
              ..._grouped(app)
            else
              for (final n in _items) _tile(app, n),
          ],
        ),
      );
    }

    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: Text.rich(
              const TextSpan(
                text: 'শীর্ষ খবর',
                children: [TextSpan(text: '.', style: TextStyle(color: flagRed))],
              ),
              style: serif(size: 28, weight: FontWeight.w700, height: 1.25),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Text(
              'একই বিষয়ে কোন পত্রিকা কী লিখছে, এক নজরে',
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(color: cs.onSurfaceVariant),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _ctl,
              textInputAction: TextInputAction.search,
              onSubmitted: (v) => _load(v.trim()),
              decoration: InputDecoration(
                hintText: 'বিষয় লিখুন, যেমন: বাজেট, বন্যা',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.arrow_forward_rounded),
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    _load(_ctl.text.trim());
                  },
                ),
                filled: true,
                fillColor: cs.surfaceContainerLowest,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: cs.outlineVariant),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: cs.outlineVariant),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: _topics.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final value = i == 0 ? '' : _topics[i];
                final on = _topic == value;
                return ChoiceChip(
                  label: Text(_topics[i]),
                  selected: on,
                  showCheckmark: false,
                  selectedColor: cs.primary,
                  labelStyle: TextStyle(
                    color: on ? cs.onPrimary : cs.onSurface,
                    fontWeight: on ? FontWeight.w600 : FontWeight.w500,
                  ),
                  onSelected: (_) {
                    HapticFeedback.selectionClick();
                    _ctl.clear();
                    _load(value);
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: SegmentedButton<bool>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: false, label: Text('সময় অনুযায়ী'), icon: Icon(Icons.schedule_rounded)),
                ButtonSegment(value: true, label: Text('পত্রিকা অনুযায়ী'), icon: Icon(Icons.view_list_rounded)),
              ],
              selected: {_bySource},
              onSelectionChanged: (s) => setState(() => _bySource = s.first),
            ),
          ),
          const SizedBox(height: 6),
          Expanded(child: body),
        ],
      ),
    );
  }
}
