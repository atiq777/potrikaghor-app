import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'add_paper_sheet.dart';
import 'widgets.dart';

/// Lets the user correct the link of ANY paper.
/// Built-in papers keep their identity (favourites stay) but open the new link.
/// Returns the saved Paper, or null if nothing changed.
Future<Paper?> showFixLinkSheet(BuildContext context, Paper paper) async {
  if (paper.custom) {
    await showPaperSheet(context, edit: paper);
    if (!context.mounted) return null;
    return context.read<AppState>().paperFor(paper.url);
  }
  return showModalBottomSheet<Paper>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    useSafeArea: true,
    builder: (_) => _FixSheet(paper),
  );
}

String? _normalizeUrl(String raw) {
  var s = raw.trim();
  if (s.isEmpty) return null;
  if (!s.startsWith('http://') && !s.startsWith('https://')) s = 'https://$s';
  final u = Uri.tryParse(s);
  if (u == null || !u.host.contains('.')) return null;
  return s;
}

class _FixSheet extends StatefulWidget {
  const _FixSheet(this.paper);

  final Paper paper;

  @override
  State<_FixSheet> createState() => _FixSheetState();
}

class _FixSheetState extends State<_FixSheet> {
  late final TextEditingController _url = TextEditingController(text: widget.paper.openUrl);
  String? _error;

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  void _save() {
    final url = _normalizeUrl(_url.text);
    if (url == null) {
      setState(() => _error = 'সঠিক লিংক দিন (যেমন: www.example.com)');
      return;
    }
    final app = context.read<AppState>();
    app.setUrlFix(widget.paper.url, url);
    HapticFeedback.mediumImpact();
    toast(context, '${widget.paper.bn}-এর লিংক ঠিক করা হয়েছে');
    Navigator.of(context).pop(app.paperFor(widget.paper.url));
  }

  void _reset() {
    final app = context.read<AppState>();
    app.setUrlFix(widget.paper.url, null);
    toast(context, 'আগের লিংকে ফেরানো হয়েছে');
    Navigator.of(context).pop(app.paperFor(widget.paper.url));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final changed = widget.paper.fix != null;
    return Padding(
      padding: EdgeInsets.fromLTRB(22, 0, 22, 22 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                PaperAvatar(widget.paper, size: 56),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(widget.paper.bn, style: serif(size: 20, weight: FontWeight.w700)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'নতুন ঠিক লিংকটা এখানে বসান। প্রিয় তালিকা ও বুকমার্ক আগের মতোই থাকবে।',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _url,
              onChanged: (_) => setState(() => _error = null),
              onSubmitted: (_) => _save(),
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'ওয়েবসাইট লিংক',
                hintText: 'www.example.com',
                prefixIcon: Icon(Icons.link_rounded),
                border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14))),
              ),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(_error!, style: TextStyle(color: cs.error, fontSize: 13)),
              ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.check_rounded),
                label: const Text('সংরক্ষণ করুন'),
              ),
            ),
            if (changed) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: _reset,
                  child: const Text('আগের লিংকে ফিরে যান'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
