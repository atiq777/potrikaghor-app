import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../data/papers.dart';
import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'settings_page.dart';
import 'widgets.dart';

class PapersTab extends StatefulWidget {
  const PapersTab({super.key});

  @override
  State<PapersTab> createState() => _PapersTabState();
}

class _PapersTabState extends State<PapersTab> with AutomaticKeepAliveClientMixin {
  final _search = TextEditingController();
  String _cat = 'all';
  String _query = '';

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Paper> _filtered(List<Paper> source, String cat) {
    final q = _query.trim().toLowerCase();
    return source.where((p) {
      if (cat == 'mine') {
        if (!p.custom) return false;
      } else if (cat != 'all' && p.cat != cat) {
        return false;
      }
      if (q.isEmpty) return true;
      return '${p.bn} ${p.en} ${p.url}'.toLowerCase().contains(q);
    }).toList();
  }

  void _reset() {
    _search.clear();
    setState(() {
      _query = '';
      _cat = 'all';
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final cs = Theme.of(context).colorScheme;
    final app = context.watch<AppState>();
    final hasMine = app.customPapers.isNotEmpty;
    final cats = <Cat>[
      categories.first,
      if (hasMine) mineCat,
      ...categories.skip(1),
    ];
    final cat = (_cat == 'mine' && !hasMine) ? 'all' : _cat;
    final items = _filtered(app.allPapers, cat);
    final recents = app.recents.map(app.paperFor).whereType<Paper>().toList();
    final showHome = _query.isEmpty && cat == 'all';
    final favPapers = app.favs.map(app.paperFor).whereType<Paper>().toList();
    final showFavs = showHome && favPapers.isNotEmpty;
    final showRecents = showHome && recents.isNotEmpty;

    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: cs.outlineVariant),
    );

    return CustomScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      slivers: [
        SliverAppBar(
          floating: true,
          snap: true,
          toolbarHeight: 68,
          titleSpacing: 16,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text.rich(
                const TextSpan(
                  text: 'পত্রিকাঘর',
                  children: [TextSpan(text: '.', style: TextStyle(color: flagRed))],
                ),
                style: serif(size: 28, weight: FontWeight.w700, height: 1.25),
              ),
              Text(
                bnToday(),
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: app.gridView ? 'তালিকা ভিউ' : 'গ্রিড ভিউ',
              icon: AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                child: Icon(
                  app.gridView ? Icons.view_agenda_outlined : Icons.grid_view_rounded,
                  key: ValueKey(app.gridView),
                ),
              ),
              onPressed: () {
                HapticFeedback.selectionClick();
                app.setGridView(!app.gridView);
              },
            ),
            IconButton(
              tooltip: 'সেটিংস',
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const SettingsPage()),
              ),
            ),
            const SizedBox(width: 4),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(112),
            child: SizedBox(
              height: 112,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                    child: SizedBox(
                      height: 48,
                      child: TextField(
                        controller: _search,
                        onChanged: (v) => setState(() => _query = v),
                        textInputAction: TextInputAction.search,
                        decoration: InputDecoration(
                          hintText: 'পত্রিকার নাম বা ওয়েবসাইট খুঁজুন',
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: _query.isEmpty
                              ? null
                              : IconButton(
                                  icon: const Icon(Icons.close),
                                  tooltip: 'মুছুন',
                                  onPressed: () {
                                    _search.clear();
                                    setState(() => _query = '');
                                  },
                                ),
                          filled: true,
                          fillColor: cs.surfaceContainerLowest,
                          contentPadding: EdgeInsets.zero,
                          border: border,
                          enabledBorder: border,
                          focusedBorder: border.copyWith(
                            borderSide: BorderSide(color: cs.primary, width: 1.5),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 44,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      clipBehavior: Clip.none,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      itemCount: cats.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) {
                        final c = cats[i];
                        final on = cat == c.id;
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: on
                                ? [
                                    BoxShadow(
                                      color: cs.primary.withValues(alpha: 0.38),
                                      blurRadius: 12,
                                      spreadRadius: 0.5,
                                    ),
                                  ]
                                : const [],
                          ),
                          child: ChoiceChip(
                            label: Text(c.label),
                            selected: on,
                            showCheckmark: false,
                            selectedColor: cs.primary,
                            labelStyle: TextStyle(
                              color: on ? cs.onPrimary : cs.onSurface,
                              fontWeight: on ? FontWeight.w600 : FontWeight.w500,
                            ),
                            onSelected: (_) {
                              HapticFeedback.selectionClick();
                              setState(() => _cat = c.id);
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (showHome)
          SliverToBoxAdapter(
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 650),
              curve: Curves.easeOutCubic,
              builder: (_, v, child) => Opacity(
                opacity: v,
                child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: child),
              ),
              child: _HeroCard(
                total: app.allPapers.length,
                favs: app.favs.length,
                last: recents.isNotEmpty ? recents.first : null,
              ),
            ),
          ),
        if (showFavs)
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
                  child: const _SectionTitle('প্রিয় পত্রিকা'),
                ),
                SizedBox(
                  height: 98,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: favPapers.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, i) => _FavBubble(favPapers[i]),
                  ),
                ),
              ],
            ),
          ),
        if (showRecents)
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                  child: const _SectionTitle('আবার পড়ুন'),
                ),
                SizedBox(
                  height: 76,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: recents.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, i) => _RecentCard(recents[i]),
                  ),
                ),
              ],
            ),
          ),
        if (items.isNotEmpty)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
              child: Text(
                '${bnDigits(items.length)}টি পত্রিকা',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ),
          ),
        if (items.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: EmptyState(
              icon: Icons.search_off_rounded,
              title: 'কোনো পত্রিকা পাওয়া যায়নি',
              body: 'অন্য নাম লিখে খুঁজুন অথবা বিভাগ বদলান।',
              actionLabel: 'সব পত্রিকা দেখুন',
              onAction: _reset,
            ),
          )
        else if (app.gridView)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                mainAxisExtent: 168 * MediaQuery.textScalerOf(context).scale(14) / 14,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, i) => PaperGridCard(
                  key: ValueKey('g-${items[i].url}'),
                  paper: items[i],
                  index: i,
                ),
                childCount: items.length,
              ),
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) => PaperTile(
                key: ValueKey(items[i].url),
                paper: items[i],
                section: 'papers',
                index: i,
              ),
              childCount: items.length,
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 18,
          decoration: BoxDecoration(color: flagRed, borderRadius: BorderRadius.circular(2)),
        ),
        const SizedBox(width: 8),
        Text(text, style: serif(size: 17, weight: FontWeight.w700)),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.total, required this.favs, this.last});

  final int total;
  final int favs;
  final Paper? last;

  /// greeting, subtitle, gradient colours, decorative icon - changes through the day
  (String, List<Color>, IconData) get _mood {
    final h = DateTime.now().hour;
    if (h >= 5 && h < 9) {
      return ('শুভ সকাল', const [Color(0xFFE0A03A), Color(0xFF12855D)], Icons.wb_twilight_rounded);
    }
    if (h >= 9 && h < 16) {
      return (
        h < 12 ? 'শুভ সকাল' : 'শুভ দুপুর',
        const [Color(0xFF2A93C0), Color(0xFF0A5C73)],
        Icons.wb_sunny_rounded
      );
    }
    if (h >= 16 && h < 19) {
      return ('শুভ বিকাল', const [Color(0xFFE5834A), Color(0xFF8E3B46)], Icons.wb_twilight_rounded);
    }
    if (h >= 19 && h < 22) {
      return ('শুভ সন্ধ্যা', const [Color(0xFF3D4E8C), Color(0xFF14283F)], Icons.nights_stay_rounded);
    }
    return ('শুভ রাত্রি', const [Color(0xFF1B3A4B), Color(0xFF0A2A22)], Icons.nights_stay_rounded);
  }

  /// Frosted-glass chip
  Widget _glass(IconData icon, String text) => ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withValues(alpha: 0.30)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 15, color: Colors.white),
                const SizedBox(width: 6),
                Text(text, style: const TextStyle(color: Colors.white, fontSize: 12.5)),
              ],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final (greet, colors, icon) = _mood;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 400),
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: colors,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.first.withValues(alpha: 0.32),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -30,
            top: -40,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.10),
              ),
            ),
          ),
          Positioned(
            right: 40,
            bottom: -50,
            child: Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.07),
              ),
            ),
          ),
          Positioned(
            right: 18,
            top: 16,
            child: Icon(icon, size: 40, color: Colors.white.withValues(alpha: 0.85)),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(greet, style: serif(size: 24, weight: FontWeight.w700, color: Colors.white)),
                const SizedBox(height: 2),
                Text(
                  bnToday(),
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.80), fontSize: 12.5),
                ),
                const SizedBox(height: 8),
                Text(
                  'আজ কোন পত্রিকা পড়বেন?',
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.92), fontSize: 14.5),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _glass(Icons.newspaper_rounded, '${bnDigits(total)}টি পত্রিকা'),
                    _glass(Icons.star_rounded, '${bnDigits(favs)}টি প্রিয়'),
                  ],
                ),
                if (last != null) ...[
                  const SizedBox(height: 14),
                  Material(
                    color: Colors.white.withValues(alpha: 0.94),
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        HapticFeedback.selectionClick();
                        openReader(context, last!);
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.play_arrow_rounded, color: colors.last, size: 22),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                'চালিয়ে পড়ুন · ${last!.bn}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: colors.last,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RecentCard extends StatelessWidget {
  const _RecentCard(this.paper);

  final Paper paper;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tag = 'recent-${paper.url}';
    return SizedBox(
      width: 172,
      child: Material(
        color: cs.surfaceContainerLowest,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: cs.outlineVariant),
        ),
        child: InkWell(
          onTap: () => openReader(context, paper, heroTag: tag),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Hero(tag: tag, child: PaperAvatar(paper, size: 40)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    paper.bn,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: serif(size: 14.5, weight: FontWeight.w500, height: 1.3),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class _FavBubble extends StatelessWidget {
  const _FavBubble(this.paper);

  final Paper paper;

  @override
  Widget build(BuildContext context) {
    final tag = 'fav-${paper.url}';
    return SizedBox(
      width: 74,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => openReader(context, paper, heroTag: tag),
        child: Column(
          children: [
            Hero(tag: tag, child: PaperAvatar(paper, size: 58)),
            const SizedBox(height: 6),
            Text(
              paper.bn,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 11.5),
            ),
          ],
        ),
      ),
    );
  }
}
