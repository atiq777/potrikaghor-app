import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../util.dart';
import 'widgets.dart';

class FavoritesTab extends StatelessWidget {
  const FavoritesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    final items = app.favs.map(app.paperFor).whereType<Paper>().toList();

    return CustomScrollView(
      slivers: [
        const SliverAppBar.large(title: Text('প্রিয় পত্রিকা')),
        if (items.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: EmptyState(
              icon: Icons.star_outline_rounded,
              title: 'এখনো কোনো প্রিয় পত্রিকা নেই',
              body: 'পত্রিকার পাশের তারা চাপলে সেটি এখানে জমা হবে।',
            ),
          )
        else ...[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(
                'ডানের হাতল ধরে টেনে সাজান · বাঁয়ে সরিয়ে বাদ দিন',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ),
          ),
          SliverReorderableList(
            itemCount: items.length,
            onReorder: (oldIndex, newIndex) {
              if (newIndex > oldIndex) newIndex -= 1;
              app.reorderFavs(oldIndex, newIndex);
            },
            proxyDecorator: (child, index, animation) => Material(
              color: Colors.transparent,
              elevation: 6,
              shadowColor: Colors.black45,
              child: child,
            ),
            itemBuilder: (context, i) {
              final p = items[i];
              return Dismissible(
                key: ValueKey('fav-${p.url}'),
                direction: DismissDirection.endToStart,
                background: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    color: cs.errorContainer,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 24),
                  child: Icon(Icons.delete_outline, color: cs.onErrorContainer),
                ),
                onDismissed: (_) {
                  final index = i;
                  app.removeFav(p.url);
                  toast(
                    context,
                    '${p.bn} প্রিয় থেকে সরানো হয়েছে',
                    action: SnackBarAction(
                      label: 'ফিরিয়ে আনুন',
                      onPressed: () => app.restoreFav(p.url, index),
                    ),
                  );
                },
                child: PaperTile(
                  paper: p,
                  section: 'fav',
                  animate: false,
                  trailing: ReorderableDragStartListener(
                    index: i,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Icon(Icons.drag_indicator, color: cs.outline),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }
}
