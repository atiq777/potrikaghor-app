import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../util.dart';
import 'add_paper_sheet.dart';
import 'bookmarks_tab.dart';
import 'compare_tab.dart';
import 'favorites_tab.dart';
import 'papers_tab.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _pages = PageController();
  int _index = 0;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  void _go(int i) => _pages.animateToPage(
        i,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
      );

  @override
  Widget build(BuildContext context) {
    final favCount = context.select<AppState, int>((s) => s.favs.length);
    final bmCount = context.select<AppState, int>((s) => s.bookmarks.length);

    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _go(0);
      },
      child: Scaffold(
        body: PageView(
          controller: _pages,
          onPageChanged: (i) => setState(() => _index = i),
          children: const [PapersTab(), CompareTab(), FavoritesTab(), BookmarksTab()],
        ),
        floatingActionButton: _index == 0
            ? FloatingActionButton.extended(
                onPressed: () => showPaperSheet(context),
                icon: const Icon(Icons.add_rounded),
                label: const Text('পত্রিকা যোগ করুন'),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: _go,
          destinations: [
            const NavigationDestination(
              icon: Icon(Icons.newspaper_outlined),
              selectedIcon: Icon(Icons.newspaper),
              label: 'পত্রিকা',
            ),
            const NavigationDestination(
              icon: Icon(Icons.compare_arrows_rounded),
              selectedIcon: Icon(Icons.compare_arrows_rounded),
              label: 'তুলনা',
            ),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: favCount > 0,
                label: Text(bnDigits(favCount)),
                child: const Icon(Icons.star_outline_rounded),
              ),
              selectedIcon: const Icon(Icons.star_rounded),
              label: 'প্রিয়',
            ),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: bmCount > 0,
                label: Text(bnDigits(bmCount)),
                child: const Icon(Icons.bookmark_outline_rounded),
              ),
              selectedIcon: const Icon(Icons.bookmark_rounded),
              label: 'বুকমার্ক',
            ),
          ],
        ),
      ),
    );
  }
}
