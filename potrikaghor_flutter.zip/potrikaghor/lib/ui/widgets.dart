import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'add_paper_sheet.dart';
import 'reader_page.dart';

Color avatarColor(String seed, Brightness b) {
  var h = 0;
  for (final c in seed.runes) {
    h = (h * 31 + c) % 360;
  }
  return HSLColor.fromAHSL(1, h.toDouble(), 0.42, b == Brightness.dark ? 0.30 : 0.34).toColor();
}

/// Opens the in-app reader with a soft fade + rise transition.
Future<void> openReader(BuildContext context, Paper paper, {String? url, String? heroTag}) {
  return Navigator.of(context).push<void>(PageRouteBuilder<void>(
    transitionDuration: const Duration(milliseconds: 340),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => ReaderPage(paper: paper, url: url ?? paper.url, heroTag: heroTag),
    transitionsBuilder: (_, anim, __, child) {
      final curved = CurvedAnimation(
        parent: anim,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeInCubic,
      );
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero).animate(curved),
          child: child,
        ),
      );
    },
  ));
}

/// Shows the newspaper's real website logo; a coloured letter tile is shown
/// while it loads (or if the logo can't be fetched, e.g. offline).
class PaperAvatar extends StatelessWidget {
  const PaperAvatar(this.paper, {super.key, this.size = 44});

  final Paper paper;
  final double size;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final seed = paper.en.isEmpty ? paper.bn : paper.en;
    final letter = Container(
      color: avatarColor(seed, Theme.of(context).brightness),
      alignment: Alignment.center,
      child: Text(
        String.fromCharCode(paper.bn.runes.first),
        style: serif(size: size * 0.46, color: Colors.white, weight: FontWeight.w700),
      ),
    );

    return Material(
      type: MaterialType.transparency,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(size * 0.3),
          border: Border.all(color: cs.outlineVariant),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.07),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(size * 0.28),
          child: Stack(
            fit: StackFit.expand,
            children: [
              letter,
              if (paper.host.isNotEmpty)
                Image.network(
                  paper.logoUrl,
                  fit: BoxFit.contain,
                  filterQuality: FilterQuality.medium,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  frameBuilder: (context, child, frame, _) {
                    if (frame == null) return const SizedBox.shrink();
                    return TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: 1),
                      duration: const Duration(milliseconds: 280),
                      builder: (_, v, __) => Opacity(
                        opacity: v,
                        child: Container(
                          color: Colors.white,
                          padding: EdgeInsets.all(size * 0.2),
                          child: child,
                        ),
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class StarButton extends StatelessWidget {
  const StarButton(this.paper, {super.key});

  final Paper paper;

  @override
  Widget build(BuildContext context) {
    final fav = context.select<AppState, bool>((s) => s.isFav(paper.url));
    return IconButton(
      tooltip: fav ? 'প্রিয় থেকে সরান' : 'প্রিয়তে যোগ করুন',
      onPressed: () {
        HapticFeedback.selectionClick();
        final state = context.read<AppState>();
        state.toggleFav(paper.url);
        if (!fav) toast(context, '${paper.bn} প্রিয়তে যোগ হয়েছে');
      },
      icon: AnimatedSwitcher(
        duration: const Duration(milliseconds: 220),
        transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
        child: Icon(
          fav ? Icons.star_rounded : Icons.star_outline_rounded,
          key: ValueKey(fav),
          color: fav ? flagRed : Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

/// Compact card used in grid view: big logo, name, and a star.
class PaperGridCard extends StatelessWidget {
  const PaperGridCard({super.key, required this.paper, this.index = 0});

  final Paper paper;
  final int index;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tag = 'grid-${paper.url}';

    final card = Material(
      color: cs.surfaceContainerLowest,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: cs.outlineVariant),
      ),
      child: InkWell(
        onTap: () => openReader(context, paper, heroTag: tag),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 16, 10, 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Hero(tag: tag, child: PaperAvatar(paper, size: 62)),
                  const SizedBox(height: 10),
                  Text(
                    paper.bn,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: serif(size: 14.5, weight: FontWeight.w500, height: 1.3),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    paper.host,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: cs.onSurfaceVariant, fontSize: 11),
                  ),
                ],
              ),
            ),
            Positioned(top: 0, right: 0, child: StarButton(paper)),
            if (paper.custom) Positioned(top: 0, left: 0, child: CustomPaperMenu(paper)),
          ],
        ),
      ),
    );

    if (index >= 12) return card;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 260 + index * 40),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) => Opacity(
        opacity: v,
        child: Transform.scale(scale: 0.94 + 0.06 * v, child: child),
      ),
      child: card,
    );
  }
}

class PaperTile extends StatelessWidget {
  const PaperTile({
    super.key,
    required this.paper,
    required this.section,
    this.index = 0,
    this.trailing,
    this.animate = true,
  });

  final Paper paper;
  final String section;
  final int index;
  final Widget? trailing;
  final bool animate;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tag = '$section-${paper.url}';

    final tile = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Material(
        color: cs.surfaceContainerLowest,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: cs.outlineVariant),
        ),
        child: InkWell(
          onTap: () => openReader(context, paper, heroTag: tag),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
            child: Row(
              children: [
                Hero(tag: tag, child: PaperAvatar(paper, size: 50)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              paper.bn,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: serif(size: 16.5, weight: FontWeight.w500, height: 1.35),
                            ),
                          ),
                          if (paper.custom) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1),
                              decoration: BoxDecoration(
                                color: cs.primaryContainer,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                'আমার',
                                style: TextStyle(
                                  fontSize: 10.5,
                                  color: cs.onPrimaryContainer,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      Text(
                        paper.en.isEmpty ? paper.host : '${paper.en} · ${paper.host}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context)
                            .textTheme
                            .bodySmall
                            ?.copyWith(color: cs.onSurfaceVariant),
                      ),
                    ],
                  ),
                ),
                trailing ??
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        StarButton(paper),
                        if (paper.custom) CustomPaperMenu(paper) else const SizedBox(width: 4),
                      ],
                    ),
              ],
            ),
          ),
        ),
      ),
    );

    if (!animate || index >= 10) return tile;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 260 + index * 40),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, (1 - v) * 14), child: child),
      ),
      child: tile,
    );
  }
}

/// ⋮ menu for papers the user added: edit or delete (with undo).
class CustomPaperMenu extends StatelessWidget {
  const CustomPaperMenu(this.paper, {super.key});

  final Paper paper;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: 'আরও',
      icon: const Icon(Icons.more_vert_rounded),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      onSelected: (v) {
        if (v == 'edit') {
          showPaperSheet(context, edit: paper);
        } else {
          final app = context.read<AppState>();
          final index = app.customPapers.indexWhere((p) => p.url == paper.url);
          app.removeCustom(paper.url);
          toast(
            context,
            '${paper.bn} মুছে ফেলা হয়েছে',
            action: SnackBarAction(label: 'ফিরিয়ে আনুন', onPressed: () => app.restoreCustom(paper, index)),
          );
        }
      },
      itemBuilder: (_) => const [
        PopupMenuItem(value: 'edit', child: Text('সম্পাদনা করুন')),
        PopupMenuItem(value: 'delete', child: Text('মুছে ফেলুন')),
      ],
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.body,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String body;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 36),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: cs.outline),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: serif(size: 19)),
            const SizedBox(height: 6),
            Text(
              body,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
            ),
            if (actionLabel != null) ...[
              const SizedBox(height: 18),
              FilledButton.tonal(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}
