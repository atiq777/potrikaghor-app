import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'fix_url_sheet.dart';
import 'widgets.dart';

enum _St { pending, ok, maybe, bad }

class _Item {
  _Item(this.paper);

  Paper paper;
  _St st = _St.pending;
  String note = '';
}

const _ua = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';

/// Tests every newspaper link from the phone and lists the ones that fail.
class LinkCheckPage extends StatefulWidget {
  const LinkCheckPage({super.key});

  @override
  State<LinkCheckPage> createState() => _LinkCheckPageState();
}

class _LinkCheckPageState extends State<LinkCheckPage> {
  late final List<_Item> _items = context.read<AppState>().allPapers.map(_Item.new).toList();
  bool _running = false;
  bool _cancel = false;
  bool _started = false;
  String? _banner;
  int _done = 0;

  @override
  void dispose() {
    _cancel = true;
    super.dispose();
  }

  Future<(_St, String)> _check(Paper p) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    try {
      final req = await client.getUrl(Uri.parse(p.openUrl));
      req.followRedirects = true;
      req.maxRedirects = 6;
      req.headers.set(HttpHeaders.userAgentHeader, _ua);
      req.headers.set(HttpHeaders.acceptHeader, 'text/html,application/xhtml+xml,*/*;q=0.8');
      final res = await req.close().timeout(const Duration(seconds: 15));
      final code = res.statusCode;
      // We only need the status; stop downloading the page right away.
      await res.listen((_) {}).cancel();
      if (code >= 200 && code < 400) return (_St.ok, 'ঠিক আছে');
      if (code == 404 || code == 410) return (_St.bad, 'পাতা নেই ($code)');
      return (_St.maybe, 'সাইট সাড়া দিয়েছে কিন্তু আটকাচ্ছে ($code)');
    } on SocketException catch (e) {
      final m = '${e.message} ${e.osError?.message ?? ''}';
      if (m.contains('Failed host lookup')) return (_St.bad, 'সাইটের ঠিকানা পাওয়া যায়নি');
      return (_St.maybe, 'সংযোগ হয়নি');
    } on TimeoutException {
      return (_St.maybe, 'সাড়া দিতে অনেক দেরি');
    } on HandshakeException {
      return (_St.maybe, 'নিরাপত্তা সনদে সমস্যা');
    } catch (_) {
      return (_St.maybe, 'যাচাই করা যায়নি');
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _start() async {
    setState(() {
      for (final i in _items) {
        i.st = _St.pending;
        i.note = '';
      }
      _running = true;
      _cancel = false;
      _started = true;
      _done = 0;
      _banner = null;
    });

    // Make sure the phone is online first, so a dead connection isn't blamed on the papers.
    try {
      final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
      final r = await (await c.getUrl(Uri.parse('https://www.google.com/generate_204')))
          .close()
          .timeout(const Duration(seconds: 10));
      await r.listen((_) {}).cancel();
      c.close(force: true);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _running = false;
        _started = false;
        _banner = 'ইন্টারনেট সংযোগ পাওয়া যায়নি। সংযোগ চালু করে আবার চেষ্টা করুন।';
      });
      return;
    }

    var next = 0;
    Future<void> worker() async {
      while (!_cancel && next < _items.length) {
        final it = _items[next++];
        final r = await _check(it.paper);
        if (!mounted) return;
        setState(() {
          it.st = r.$1;
          it.note = r.$2;
          _done++;
        });
      }
    }

    await Future.wait(List.generate(8, (_) => worker()));
    if (mounted) setState(() => _running = false);
  }

  Future<void> _fix(_Item it) async {
    final p = await showFixLinkSheet(context, it.paper);
    if (p == null || !mounted) return;
    setState(() {
      it.paper = p;
      it.st = _St.pending;
      it.note = 'আবার যাচাই হচ্ছে...';
    });
    final r = await _check(p);
    if (!mounted) return;
    setState(() {
      it.st = r.$1;
      it.note = r.$2;
    });
    toast(context, r.$1 == _St.ok ? 'নতুন লিংক ঠিকমতো খুলছে ✓' : 'নতুন লিংকেও সমস্যা: ${r.$2}');
  }

  String _report() {
    final b = StringBuffer('পত্রিকাঘর লিংক যাচাই');
    void section(String title, _St st) {
      final list = _items.where((i) => i.st == st).toList();
      if (list.isEmpty) return;
      b.writeln('\n\n$title (${list.length}):');
      for (final i in list) {
        b.writeln('- ${i.paper.bn} | ${i.paper.openUrl} | ${i.note}');
      }
    }

    section('খোলে না', _St.bad);
    section('সন্দেহজনক', _St.maybe);
    return b.toString();
  }

  Widget _stat(String label, int n, Color color) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            children: [
              Text(bnDigits(n), style: serif(size: 20, weight: FontWeight.w700, color: color)),
              const SizedBox(height: 2),
              Text(label, style: TextStyle(fontSize: 12, color: color)),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final total = _items.length;
    final okN = _items.where((i) => i.st == _St.ok).length;
    final bad = _items.where((i) => i.st == _St.bad).toList();
    final maybe = _items.where((i) => i.st == _St.maybe).toList();
    final problems = [...bad, ...maybe];
    final finished = _started && !_running && _done >= total;

    return Scaffold(
      appBar: AppBar(title: const Text('লিংক যাচাই')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Text(
            'অ্যাপ নিজেই সব পত্রিকার সাইটে সংযোগ করে দেখবে কোনটা খুলছে না। '
            'এতে অল্প ইন্টারনেট ডেটা খরচ হয়।',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
          ),
          const SizedBox(height: 14),
          if (_banner != null)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: cs.errorContainer,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(_banner!, style: TextStyle(color: cs.onErrorContainer)),
            ),
          if (_started) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(value: total == 0 ? 0 : _done / total, minHeight: 8),
            ),
            const SizedBox(height: 6),
            Text(
              '${bnDigits(_done)} / ${bnDigits(total)} যাচাই হয়েছে',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _stat('ঠিক আছে', okN, const Color(0xFF2E9E5B)),
                const SizedBox(width: 8),
                _stat('সন্দেহজনক', maybe.length, const Color(0xFFD98A1F)),
                const SizedBox(width: 8),
                _stat('খোলে না', bad.length, const Color(0xFFD4382C)),
              ],
            ),
            const SizedBox(height: 14),
          ],
          SizedBox(
            height: 50,
            child: FilledButton.icon(
              onPressed: _running ? () => setState(() => _cancel = true) : _start,
              icon: Icon(_running ? Icons.stop_rounded : Icons.fact_check_rounded),
              label: Text(_running ? 'থামান' : (_started ? 'আবার যাচাই করুন' : 'যাচাই শুরু করুন')),
            ),
          ),
          if (problems.isNotEmpty && !_running) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: _report()));
                      toast(context, 'তালিকা কপি হয়েছে। আমাকে পাঠাতে পারেন');
                    },
                    icon: const Icon(Icons.copy_rounded, size: 18),
                    label: const Text('তালিকা কপি'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Share.share(_report()),
                    icon: const Icon(Icons.ios_share_rounded, size: 18),
                    label: const Text('শেয়ার'),
                  ),
                ),
              ],
            ),
          ],
          if (finished && problems.isEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 24),
              child: Center(
                child: Text(
                  'সব পত্রিকার সাইট সাড়া দিচ্ছে 🎉',
                  style: serif(size: 17, weight: FontWeight.w600),
                ),
              ),
            ),
          if (problems.isNotEmpty) ...[
            const SizedBox(height: 18),
            Text('সমস্যা পাওয়া গেছে', style: serif(size: 17, weight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              'পত্রিকা চাপলে অ্যাপের ভেতরে খুলে দেখতে পারবেন। সঠিক লিংক জানা থাকলে নিচের "লিংক ঠিক করুন" চাপুন। '
              '"সন্দেহজনক" মানে অনেক সময় সাইট ঠিকই আছে, শুধু পরীক্ষাটা আটকে দিয়েছে।',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            for (final i in problems)
              Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                color: cs.surfaceContainerLowest,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: BorderSide(color: cs.outlineVariant),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: PaperAvatar(i.paper, size: 40),
                      title: Text(i.paper.bn, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${i.paper.host}\n${i.note}'),
                      isThreeLine: true,
                      trailing: Icon(
                        i.st == _St.bad ? Icons.error_rounded : Icons.warning_amber_rounded,
                        color: i.st == _St.bad ? const Color(0xFFD4382C) : const Color(0xFFD98A1F),
                      ),
                      onTap: () => openReader(context, i.paper),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () => _fix(i),
                          icon: const Icon(Icons.edit_rounded, size: 18),
                          label: const Text('লিংক ঠিক করুন'),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }
}
