import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../data/papers.dart';
import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'settings_page.dart';
import 'widgets.dart';

class PapersTab extends StatefulWidget {
  const PapersTab({super.key});

  @override
  State<PapersTab> createState() => _PapersTabState();
}

class _PapersTabState extends State<PapersTab> with AutomaticKeepAliveClientMixin {
  final _search = TextEditingController();
  String _cat = 'all';
  String _query = '';

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Paper> _filtered(List<Paper> source, String cat) {
    final q = _query.trim().toLowerCase();
    return source.where((p) {
      if (cat == 'mine') {
        if (!p.custom) return false;
      } else if (cat != 'all' && p.cat != cat) {
        return false;
      }
      if (q.isEmpty) return true;
      return '${p.bn} ${p.en} ${p.url}'.toLowerCase().contains(q);
    }).toList();
  }

  void _reset() {
    _search.clear();
    setState(() {
      _query = '';
      _cat = 'all';
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final cs = Theme.of(context).colorScheme;
    final app = context.watch<AppState>();
    final hasMine = app.customPapers.isNotEmpty;
    final cats = <Cat>[
      categories.first,
      if (hasMine) mineCat,
      ...categories.skip(1),
    ];
    final cat = (_cat == 'mine' && !hasMine) ? 'all' : _cat;
    final items = _filtered(app.allPapers, cat);
    final recents = app.recents.map(app.paperFor).whereType<Paper>().toList();
    final showHome = _query.isEmpty && cat == 'all';
    final favPapers = app.favs.map(app.paperFor).whereType<Paper>().toList();
    final showFavs = showHome && favPapers.isNotEmpty;
    final showRecents = showHome && recents.length > 1;

    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: cs.onSurface, width: 1.5),
    );

    return CustomScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      slivers: [
        SliverAppBar(
          floating: true,
          snap: true,
          toolbarHeight: 68,
          titleSpacing: 16,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text.rich(
                const TextSpan(
                  text: 'পত্রিকাঘর',
                  children: [TextSpan(text: '.', style: TextStyle(color: flagRed))],
                ),
                style: serif(size: 30, weight: FontWeight.w900, height: 1.25),
              ),
              Text(
                bnToday(),
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: app.gridView ? 'তালিকা ভিউ' : 'গ্রিড ভিউ',
              icon: AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                child: Icon(
                  app.gridView ? Icons.view_agenda_outlined : Icons.grid_view_rounded,
                  key: ValueKey(app.gridView),
                ),
              ),
              onPressed: () {
                HapticFeedback.selectionClick();
                app.setGridView(!app.gridView);
              },
            ),
            IconButton(
              tooltip: 'সেটিংস',
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const SettingsPage()),
              ),
            ),
            const SizedBox(width: 4),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(112),
            child: SizedBox(
              height: 112,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                    child: SizedBox(
                      height: 48,
                      child: TextField(
                        controller: _search,
                        onChanged: (v) => setState(() => _query = v),
                        textInputAction: TextInputAction.search,
                        decoration: InputDecoration(
                          hintText: 'পত্রিকার নাম বা ওয়েবসাইট খুঁজুন',
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: _query.isEmpty
                              ? null
                              : IconButton(
                                  icon: const Icon(Icons.close),
                                  tooltip: 'মুছুন',
                                  onPressed: () {
                                    _search.clear();
                                    setState(() => _query = '');
                                  },
                                ),
                          filled: true,
                          fillColor: Colors.transparent,
                          contentPadding: EdgeInsets.zero,
                          border: border,
                          enabledBorder: border,
                          focusedBorder: border.copyWith(
                            borderSide: BorderSide(color: cs.primary, width: 1.5),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 44,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(color: cs.outlineVariant)),
                      ),
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: cats.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 22),
                        itemBuilder: (_, i) {
                          final c = cats[i];
                          final on = cat == c.id;
                          return InkWell(
                            onTap: () {
                              HapticFeedback.selectionClick();
                              setState(() => _cat = c.id);
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              curve: Curves.easeOut,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: on ? cs.primary : Colors.transparent,
                                    width: 3,
                                  ),
                                ),
                              ),
                              child: Text(
                                c.label,
                                style: TextStyle(
                                  fontSize: 14.5,
                                  color: on ? cs.onSurface : cs.onSurfaceVariant,
                                  fontWeight: on ? FontWeight.w700 : FontWeight.w500,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (showHome)
          SliverToBoxAdapter(
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 650),
              curve: Curves.easeOutCubic,
              builder: (_, v, child) => Opacity(
                opacity: v,
                child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: child),
              ),
              child: _ContinueCard(
                total: app.allPapers.length,
                favs: app.favs.length,
                last: recents.isNotEmpty ? recents.first : null,
              ),
            ),
          ),
        if (showFavs)
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
                  child: const _SectionTitle('প্রিয় পত্রিকা'),
                ),
                SizedBox(
                  height: 98,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: favPapers.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, i) => _FavBubble(favPapers[i]),
                  ),
                ),
              ],
            ),
          ),
        if (showRecents)
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                  child: const _SectionTitle('আবার পড়ুন'),
                ),
                SizedBox(
                  height: 76,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: recents.length - 1,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, i) => _RecentCard(recents[i + 1]),
                  ),
                ),
              ],
            ),
          ),
        if (items.isNotEmpty)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
              child: Text(
                '${bnDigits(items.length)}টি পত্রিকা',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ),
          ),
        if (items.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: EmptyState(
              icon: Icons.search_off_rounded,
              title: 'কোনো পত্রিকা পাওয়া যায়নি',
              body: 'অন্য নাম লিখে খুঁজুন অথবা বিভাগ বদলান।',
              actionLabel: 'সব পত্রিকা দেখুন',
              onAction: _reset,
            ),
          )
        else if (app.gridView)
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                mainAxisExtent: 168 * MediaQuery.textScalerOf(context).scale(14) / 14,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, i) => PaperGridCard(
                  key: ValueKey('g-${items[i].url}'),
                  paper: items[i],
                  index: i,
                ),
                childCount: items.length,
              ),
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) => PaperTile(
                key: ValueKey(items[i].url),
                paper: items[i],
                section: 'papers',
                index: i,
              ),
              childCount: items.length,
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(width: 28, height: 3, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 6),
        Text(text, style: serif(size: 19, weight: FontWeight.w700)),
      ],
    );
  }
}

/// Dark "continue reading" card (or a quiet count line when nothing was read yet).
class _ContinueCard extends StatelessWidget {
  const _ContinueCard({required this.total, required this.favs, this.last});

  final int total;
  final int favs;
  final Paper? last;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final bg = dark ? cs.surfaceContainerHigh : inkColor;
    const soft = Color(0xFFB9AFA0);

    final count = Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      child: Text(
        '${bnDigits(total)}টি পত্রিকা এক জায়গায় · ${bnDigits(favs)}টি প্রিয়',
        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
      ),
    );
    if (last == null) return count;

    final p = last!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(22),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            HapticFeedback.selectionClick();
            openReader(context, p);
          },
          child: Stack(
            children: [
              Positioned(
                right: -6,
                top: -30,
                child: Text(
                  p.bn.characters.take(2).toString(),
                  style: serif(size: 140, weight: FontWeight.w900, color: paperColor.withValues(alpha: 0.06)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    PaperAvatar(p, size: 56),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'চালিয়ে পড়ুন',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.4,
                              color: Color.lerp(cs.primary, Colors.white, 0.35),
                            ),
                          ),
                          Text(
                            p.bn,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: serif(size: 22, weight: FontWeight.w700, color: paperColor, height: 1.35),
                          ),
                          Text(p.host, style: const TextStyle(fontSize: 12.5, color: soft)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(color: cs.primary, shape: BoxShape.circle),
                      child: Icon(Icons.play_arrow_rounded, color: cs.onPrimary, size: 26),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RecentCard extends StatelessWidget {
  const _RecentCard(this.paper);

  final Paper paper;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tag = 'recent-${paper.url}';
    return SizedBox(
      width: 172,
      child: Material(
        color: cs.surfaceContainerLowest,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: cs.outlineVariant),
        ),
        child: InkWell(
          onTap: () => openReader(context, paper, heroTag: tag),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Hero(tag: tag, child: PaperAvatar(paper, size: 40)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    paper.bn,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: serif(size: 14.5, weight: FontWeight.w500, height: 1.3),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class _FavBubble extends StatelessWidget {
  const _FavBubble(this.paper);

  final Paper paper;

  @override
  Widget build(BuildContext context) {
    final tag = 'fav-${paper.url}';
    return SizedBox(
      width: 74,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => openReader(context, paper, heroTag: tag),
        child: Column(
          children: [
            Hero(tag: tag, child: PaperAvatar(paper, size: 58)),
            const SizedBox(height: 6),
            Text(
              paper.bn,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 11.5),
            ),
          ],
        ),
      ),
    );
  }
}
